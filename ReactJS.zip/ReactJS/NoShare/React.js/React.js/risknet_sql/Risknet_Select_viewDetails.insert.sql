SET DEFINE OFF;
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BAMRC000000', 'BANK OF AMERICA CORPORATION', 'Y', 'N', '7', 
    '5', '5', '0', '0', '23506080', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BAMRC000000', 'BANK OF AMERICA CORPORATION', 'Y', 'N', '7', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BOKFI000000', 'BOK FINANCIAL CORPORATION', '', 'N', '8', 
    '7', '7', '0', '0', '362313.48', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BOKFI000000', 'BOK FINANCIAL CORPORATION', '', 'N', '8', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEPNC000000', 'PEOPLES BANCORP OF NORTH CAROLINA, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEPNC000000', 'PEOPLES BANCORP OF NORTH CAROLINA, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '13917', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INDPB000000', 'PEOPLES BANCORP', '', 'N', '8', 
    '7', '7', '0', '0', '21710.76', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INDPB000000', 'PEOPLES BANCORP', '', 'N', '8', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RJAMS000000', 'RAYMOND JAMES FINANCIAL, INC.', '', 'N', '4', 
    '4', '4', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RJAMS000000', 'RAYMOND JAMES FINANCIAL, INC.', '', 'N', '4', 
    '4', '4', '0', '0', '706219.64', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BBTFI000000', 'BB&T CORPORATION', 'Y', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BBTFI000000', 'BB&T CORPORATION', 'Y', 'N', '7', 
    '6', '6', '0', '0', '2318280', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNCHD000000', 'UNITED NATIONAL CORPORATION', '', 'N', '5', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNCHD000000', 'UNITED NATIONAL CORPORATION', '', 'N', '5', 
    '5', '5', '0', '0', '168168.84', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNTBK000000', 'UNITED BANKSHARES, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNTBK000000', 'UNITED BANKSHARES, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '188888.04', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CAMBC000000', 'CAMBRIDGE BANCORP', '', 'N', '7', 
    '7', '7', '0', '0', '17705.4', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CAMBC000000', 'CAMBRIDGE BANCORP', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MNSRC000000', 'MAINSOURCE FINANCIAL GROUP, INC.', '', 'N', '8', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MNSRC000000', 'MAINSOURCE FINANCIAL GROUP, INC.', '', 'N', '8', 
    '7', '7', '0', '0', '45836.04', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SUNTR000000', 'SUNTRUST BANKS, INC.', 'Y', 'N', '9', 
    '7', '7', '0', '0', '2244520.92', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SUNTR000000', 'SUNTRUST BANKS, INC.', 'Y', 'N', '9', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DEUTB000015', 'DB USA CORPORATION', 'Y', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DEUTB000015', 'DB USA CORPORATION', 'Y', 'N', '7', 
    '6', '6', '0', '0', '1338600', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ANBHC000001', 'THE ANB CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ANBHC000001', 'THE ANB CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '21787.92', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HAVEN000000', 'NEW YORK COMMUNITY BANCORP, INC.', 'Y', 'N', '11', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HAVEN000000', 'NEW YORK COMMUNITY BANCORP, INC.', 'Y', 'N', '11', 
    '7', '7', '0', '0', '523109.4', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GLACR000000', 'GLACIER BANCORP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '120847.44', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GLACR000000', 'GLACIER BANCORP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITUN000000', 'CITIZENS UNION BANCORP OF SHELBYVILLE, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '8774.15', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITUN000000', 'CITIZENS UNION BANCORP OF SHELBYVILLE, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNCRP000000', 'FIRST BANCORP', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNCRP000000', 'FIRST BANCORP', '', 'N', '10', 
    '10', '10', '0', '0', '48120.49', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STOCK000000', 'STOCKMAN FINANCIAL CORP.', '', 'N', '7', 
    '7', '7', '0', '0', '39127.32', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STOCK000000', 'STOCKMAN FINANCIAL CORP.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SDVBC000001', 'SOUTHERN BANCORP, INC.', '', 'N', '13', 
    '13', '13', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SDVBC000001', 'SOUTHERN BANCORP, INC.', '', 'N', '13', 
    '13', '13', '0', '0', '6154.96', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BETHL000000', 'NORTHEAST BANCORP', '', 'N', '8', 
    '7', '7', '0', '0', '15447.84', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BETHL000000', 'NORTHEAST BANCORP', '', 'N', '8', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BOILS000000', 'BOILING SPRINGS, MHC', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BOILS000000', 'BOILING SPRINGS, MHC', '', 'N', '9', 
    '9', '9', '0', '0', '23021.68', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BOSTP000000', 'BOSTON PRIVATE FINANCIAL HOLDINGS, INC.', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BOSTP000000', 'BOSTON PRIVATE FINANCIAL HOLDINGS, INC.', '', 'N', '8', 
    '9', '9', '0', '0', '70618.02', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OTTOB000014', 'BREMER BANK, NATIONAL ASSOCIATION', '', 'N', '8', 
    '8', '8', '1.3091', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OTTOB000014', 'BREMER BANK, NATIONAL ASSOCIATION', '', 'N', '8', 
    '8', '8', '1.3091', '0', '110342.43', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STTND000000', 'STATE BANKSHARES, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STTND000000', 'STATE BANKSHARES, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '37932.51', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNYCO000000', 'THE BANK OF NEW YORK MELLON CORPORATION', 'Y', 'N', '4', 
    '3', '3', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNYCO000000', 'THE BANK OF NEW YORK MELLON CORPORATION', 'Y', 'N', '4', 
    '3', '3', '0', '0', '2838640', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STLBC000000', 'STERLING BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STLBC000000', 'STERLING BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '275780.67', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNIBS000000', 'UNION BANKSHARES CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '80629.78', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNIBS000000', 'UNION BANKSHARES CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HRTLA000000', 'HEARTLAND BANCORP, INC.', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HRTLA000000', 'HEARTLAND BANCORP, INC.', '', 'N', '7', 
    '8', '8', '0', '0', '28263.62', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HORZB000000', 'HORIZON BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HORZB000000', 'HORIZON BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '35727.56', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MRDAN000000', 'MERIDIAN BANCORP, INC.', '', 'N', '9', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MRDAN000000', 'MERIDIAN BANCORP, INC.', '', 'N', '9', 
    '8', '8', '0', '0', '68586.98', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CATHY000000', 'CATHAY GENERAL BANCORP', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CATHY000000', 'CATHAY GENERAL BANCORP', '', 'N', '7', 
    '8', '8', '0', '0', '175345.5', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WSTAB000000', 'WESTAMERICA BANCORPORATION', '', 'N', '4', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WSTAB000000', 'WESTAMERICA BANCORPORATION', '', 'N', '4', 
    '5', '5', '0', '0', '55765.92', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ZIONB000000', 'ZIONS BANCORPORATION', 'Y', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ZIONB000000', 'ZIONS BANCORPORATION', 'Y', 'N', '7', 
    '6', '6', '0', '0', '799511.64', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MORGS000000', 'MORGAN STANLEY', 'Y', 'N', '6', 
    '3', '3', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MORGS000000', 'MORGAN STANLEY', 'Y', 'N', '6', 
    '3', '3', '0', '0', '9574740', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BROWN000000', 'BOU BANCORP, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BROWN000000', 'BOU BANCORP, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '17941.44', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SYNVS000000', 'SYNOVUS FINANCIAL CORP.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SYNVS000000', 'SYNOVUS FINANCIAL CORP.', '', 'N', '9', 
    '9', '9', '0', '0', '317778.45', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TAYLR000000', 'FRANDSEN FINANCIAL CORPORATION', '', 'N', '8', 
    '7', '7', '0', '0', '14825.64', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TAYLR000000', 'FRANDSEN FINANCIAL CORPORATION', '', 'N', '8', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FULTO000000', 'FULTON FINANCIAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FULTO000000', 'FULTON FINANCIAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '186813.11', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UCOMB000000', 'UNITED COMMUNITY BANKS, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UCOMB000000', 'UNITED COMMUNITY BANKS, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '115631.67', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('VALNT000000', 'VALLEY NATIONAL BANCORP', '', 'N', '11', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('VALNT000000', 'VALLEY NATIONAL BANCORP', '', 'N', '11', 
    '11', '11', '0', '0', '145730.72', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NRTHF000000', 'NORTHWEST FINANCIAL CORP.', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NRTHF000000', 'NORTHWEST FINANCIAL CORP.', '', 'N', '7', 
    '8', '8', '0', '0', '18616.95', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OCNBS000000', 'OCEAN BANKSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OCNBS000000', 'OCEAN BANKSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '41414.34', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OLDNT000000', 'OLD NATIONAL BANCORP', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OLDNT000000', 'OLD NATIONAL BANCORP', '', 'N', '9', 
    '10', '10', '0', '0', '140036.38', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UMPUA000000', 'UMPQUA HOLDINGS CORPORATION', 'Y', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UMPUA000000', 'UMPQUA HOLDINGS CORPORATION', 'Y', 'N', '8', 
    '8', '8', '0', '0', '241606.86', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UVEST000000', 'UNIVEST CORPORATION OF PENNSYLVANIA', '', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UVEST000000', 'UNIVEST CORPORATION OF PENNSYLVANIA', '', 'N', '10', 
    '9', '9', '0', '0', '46582.69', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STATE000000', 'STATE STREET CORPORATION', 'Y', 'N', '5', 
    '3', '3', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STATE000000', 'STATE STREET CORPORATION', 'Y', 'N', '5', 
    '3', '3', '0', '0', '2055561.48', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MRKTS000000', 'MARKET STREET BANCSHARES, INC.', '', 'N', '13', 
    '14', '14', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MRKTS000000', 'MARKET STREET BANCSHARES, INC.', '', 'N', '13', 
    '14', '14', '0', '0', '4623.66', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WELLS000000', 'WELLS FARGO & COMPANY', 'Y', 'N', '6', 
    '4', '4', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WELLS000000', 'WELLS FARGO & COMPANY', 'Y', 'N', '6', 
    '4', '4', '0', '0', '24719660', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WINTS000000', 'WINTRUST FINANCIAL CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WINTS000000', 'WINTRUST FINANCIAL CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '270317.74', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TRINT000000', 'TRINITY CAPITAL CORP.', '', 'N', '10', 
    '12', '12', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TRINT000000', 'TRINITY CAPITAL CORP.', '', 'N', '10', 
    '12', '12', '0', '0', '8443.52', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('USBAC000000', 'U.S. BANCORP', 'Y', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('USBAC000000', 'U.S. BANCORP', 'Y', 'N', '7', 
    '6', '6', '0', '0', '4682760', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UBKCP000000', 'UNITED BANK CORPORATION', '', 'N', '5', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UBKCP000000', 'UNITED BANK CORPORATION', '', 'N', '5', 
    '5', '5', '0', '0', '15136.68', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('KEYCP000000', 'KEYCORP', 'Y', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('KEYCP000000', 'KEYCORP', 'Y', 'N', '7', 
    '6', '6', '0', '0', '1448259.12', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GERMN000000', 'GERMAN AMERICAN BANCORP, INC.', '', 'N', '6', 
    '7', '7', '0', '0', '37009.32', 
    '0', 'Automated-2', 'VICTORIA Y WANG', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GERMN000000', 'GERMAN AMERICAN BANCORP, INC.', '', 'N', '6', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'VICTORIA Y WANG', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MTBKC000000', 'M&T BANK CORPORATION', 'Y', 'N', '7', 
    '7', '7', '0', '0', '1390334.16', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MTBKC000000', 'M&T BANK CORPORATION', 'Y', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HSBCH000053', 'HSBC NORTH AMERICA HOLDINGS INC.', 'Y', 'N', '8', 
    '6', '6', '0', '0', '2974426.8', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HSBCH000053', 'HSBC NORTH AMERICA HOLDINGS INC.', 'Y', 'N', '8', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CFCOR000000', 'CHEMICAL FINANCIAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '164990.1', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CFCOR000000', 'CHEMICAL FINANCIAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNBSF000000', 'HOMEBANCORP, INC.', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNBSF000000', 'HOMEBANCORP, INC.', '', 'N', '8', 
    '9', '9', '0', '0', '7845.42', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('IBRIA000000', 'IBERIABANK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('IBRIA000000', 'IBERIABANK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '266748.24', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CARFC000000', 'CAROLINA FINANCIAL CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '37939.56', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CARFC000000', 'CAROLINA FINANCIAL CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HNCCK000000', 'HANCOCK WHITNEY CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '225366.57', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HNCCK000000', 'HANCOCK WHITNEY CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HERFN000000', 'HERITAGE FINANCIAL CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HERFN000000', 'HERITAGE FINANCIAL CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '41820.68', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HUNTI000000', 'HUNTINGTON BANCSHARES INCORPORATED', '', 'N', '7', 
    '7', '7', '0', '0', '1013789.04', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HUNTI000000', 'HUNTINGTON BANCSHARES INCORPORATED', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INDBC000000', 'INDEPENDENT BANK CORP.', '', 'N', '9', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INDBC000000', 'INDEPENDENT BANK CORP.', '', 'N', '9', 
    '8', '8', '0', '0', '77292.82', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ARVST000000', 'ARVEST BANK GROUP, INC.', 'Y', 'N', '11', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ARVST000000', 'ARVEST BANK GROUP, INC.', 'Y', 'N', '11', 
    '8', '8', '0', '0', '141902.2', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PNCBK000000', 'THE PNC FINANCIAL SERVICES GROUP, INC.', 'Y', 'N', '7', 
    '5', '5', '0', '0', '4561795.44', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PNCBK000000', 'THE PNC FINANCIAL SERVICES GROUP, INC.', 'Y', 'N', '7', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PRTER000000', 'LIMESTONE BANCORP, INC.', '', 'N', '14', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PRTER000000', 'LIMESTONE BANCORP, INC.', '', 'N', '14', 
    '10', '10', '0', '0', '7994.03', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GREAS000000', 'GREAT SOUTHERN BANCORP, INC.', '', 'N', '11', 
    '10', '10', '0', '0', '50689.21', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GREAS000000', 'GREAT SOUTHERN BANCORP, INC.', '', 'N', '11', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HANMI000000', 'HANMI FINANCIAL CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HANMI000000', 'HANMI FINANCIAL CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '65839.56', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('JONSB000000', 'AMERISERV FINANCIAL, INC.', '', 'N', '11', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('JONSB000000', 'AMERISERV FINANCIAL, INC.', '', 'N', '11', 
    '10', '10', '0', '0', '9147.38', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ASSBK000000', 'ASSOCIATED BANC-CORP', '', 'N', '10', 
    '10', '10', '0', '0', '247018.64', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ASSBK000000', 'ASSOCIATED BANC-CORP', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AUBUR000000', 'AUBURN NATIONAL BANCORPORATION, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AUBUR000000', 'AUBURN NATIONAL BANCORPORATION, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '10428.72', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMBOY000001', 'AMBOY BANCORPORATION', '', 'N', '11', 
    '10', '10', '0', '0', '33569.03', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMBOY000001', 'AMBOY BANCORPORATION', '', 'N', '11', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMNAT000000', 'AMERICAN NATIONAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '32623.69', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMNAT000000', 'AMERICAN NATIONAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ARROW000000', 'ARROW FINANCIAL CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '27105.36', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ARROW000000', 'ARROW FINANCIAL CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEOUT000000', 'PEOPLE''S UTAH BANCORP', '', 'N', '5', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEOUT000000', 'PEOPLE''S UTAH BANCORP', '', 'N', '5', 
    '7', '7', '0', '0', '27133.8', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEOPL000000', 'PEOPLES BANCORP INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEOPL000000', 'PEOPLES BANCORP INC.', '', 'N', '7', 
    '7', '7', '0', '0', '37952.64', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEOPH000000', 'RENASANT CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PEOPH000000', 'RENASANT CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '96549.75', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PINBC000000', 'PINNACLE BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PINBC000000', 'PINNACLE BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '102838.45', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BPONC000000', 'POPULAR, INC.', 'Y', 'N', '13', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BPONC000000', 'POPULAR, INC.', 'Y', 'N', '13', 
    '9', '9', '0', '0', '488510', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PROBA000000', 'PROSPERITY BANCSHARES, INC.', '', 'N', '4', 
    '4', '4', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PROBA000000', 'PROSPERITY BANCSHARES, INC.', '', 'N', '4', 
    '4', '4', '0', '0', '263825.24', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FNTLC000000', 'SOUTH STATE CORPORATION', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FNTLC000000', 'SOUTH STATE CORPORATION', '', 'N', '7', 
    '8', '8', '0', '0', '135909.95', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FUTDC000000', 'FIRST UNITED CORPORATION', '', 'N', '10', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FUTDC000000', 'FIRST UNITED CORPORATION', '', 'N', '10', 
    '11', '11', '0', '0', '7790.88', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EXTRA000000', 'EXTRACO CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '17685.72', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EXTRA000000', 'EXTRACO CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FALBK000000', 'FALCON BANCSHARES INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FALBK000000', 'FALCON BANCSHARES INC.', '', 'N', '8', 
    '8', '8', '0', '0', '12601.49', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FIDEL000000', 'FIDELITY SOUTHERN CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FIDEL000000', 'FIDELITY SOUTHERN CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '41512.9', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EWBAN000000', 'EAST WEST BANCORP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '402045.48', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EWBAN000000', 'EAST WEST BANCORP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FNBCP000000', 'F.N.B. CORPORATION', '', 'N', '11', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FNBCP000000', 'F.N.B. CORPORATION', '', 'N', '11', 
    '11', '11', '0', '0', '165029.84', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HMBNC000001', 'HOME BANCSHARES, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HMBNC000001', 'HOME BANCSHARES, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '134969.01', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EGGEM000003', 'PACWEST BANCORP', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EGGEM000003', 'PACWEST BANCORP', '', 'N', '7', 
    '7', '7', '0', '0', '281310.12', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AUBAN000000', 'AUSTIN BANCORP INC.', '', 'N', '7', 
    '7', '7', '0', '0', '25651.8', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AUBAN000000', 'AUSTIN BANCORP INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DURNT000000', 'DURANT BANCORP INC', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DURNT000000', 'DURANT BANCORP INC', '', 'N', '10', 
    '10', '10', '0', '0', '46479.95', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EIGHT000000', '1867 WESTERN FINANCIAL CORPORATION', '', 'N', '6', 
    '5', '5', '0', '0', '51820.2', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EIGHT000000', '1867 WESTERN FINANCIAL CORPORATION', '', 'N', '6', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNCTN000000', 'BANCTENN CORP.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNCTN000000', 'BANCTENN CORP.', '', 'N', '10', 
    '10', '10', '0', '0', '13451.57', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBNCP000000', 'FIRST BANCORP', 'Y', 'N', '15', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBNCP000000', 'FIRST BANCORP', 'Y', 'N', '15', 
    '11', '11', '0', '0', '146139.68', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ANATC000000', 'ACCESS NATIONAL CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ANATC000000', 'ACCESS NATIONAL CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '26008.73', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SCBKY000000', 'SOUTH CENTRAL BANCSHARES OF KENTUCKY, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SCBKY000000', 'SOUTH CENTRAL BANCSHARES OF KENTUCKY, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '11364.43', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CPINC000000', 'CENTRAL PACIFIC FINANCIAL CORP.', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CPINC000000', 'CENTRAL PACIFIC FINANCIAL CORP.', '', 'N', '7', 
    '8', '8', '0', '0', '54780.55', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INLND000000', 'INLAND BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '10700.58', 
    '0', 'Automated-2', 'VICTORIA Y WANG', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INLND000000', 'INLAND BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'VICTORIA Y WANG', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('215HD000000', '215 HOLDING COMPANY', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('215HD000000', '215 HOLDING COMPANY', '', 'N', '8', 
    '8', '8', '0', '0', '9655.25', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PNCLE000000', 'PINNACLE FINANCIAL PARTNERS, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '202756.4', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PNCLE000000', 'PINNACLE FINANCIAL PARTNERS, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PERRY000000', 'FIRSTPERRYTON BANCORP, INC.', '', 'N', '9', 
    '7', '7', '0', '0', '8412.12', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PERRY000000', 'FIRSTPERRYTON BANCORP, INC.', '', 'N', '9', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WHTKR000000', 'WHITAKER BANK CORPORATION OF KENTUCKY', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WHTKR000000', 'WHITAKER BANK CORPORATION OF KENTUCKY', '', 'N', '9', 
    '9', '9', '0', '0', '25529.24', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WOODF000000', 'WOODFOREST FINANCIAL GROUP, INC.', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WOODF000000', 'WOODFOREST FINANCIAL GROUP, INC.', '', 'N', '7', 
    '8', '8', '0', '0', '50361.74', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EXNGE000000', 'HAWTHORN BANCSHARES, INC.', '', 'N', '12', 
    '12', '12', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('EXNGE000000', 'HAWTHORN BANCSHARES, INC.', '', 'N', '12', 
    '12', '12', '0', '0', '7309.68', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SALSB000000', 'SALISBURY BANCORP, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SALSB000000', 'SALISBURY BANCORP, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '6548.96', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INVBC000000', 'INVESTORS BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INVBC000000', 'INVESTORS BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '334511.54', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('JPMOR000000', 'JPMORGAN CHASE & CO.', 'Y', 'N', '7', 
    '4', '4', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('JPMOR000000', 'JPMORGAN CHASE & CO.', 'Y', 'N', '7', 
    '4', '4', '0', '0', '29026340', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NSBHC000002', 'NORTHFIELD BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NSBHC000002', 'NORTHFIELD BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '65901.66', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CMOMS000000', 'COMMUNITY BANCSHARES OF MISSISSIPPI, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CMOMS000000', 'COMMUNITY BANCSHARES OF MISSISSIPPI, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '22056.32', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('COMMF000000', 'STURM FINANCIAL GROUP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '20048.16', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('COMMF000000', 'STURM FINANCIAL GROUP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CENIL000000', 'CIB MARINE BANCSHARES, INC.', '', 'N', '10', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CENIL000000', 'CIB MARINE BANCSHARES, INC.', '', 'N', '10', 
    '8', '8', '0', '0', '10655.48', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OLYBC000000', 'OLYMPIC BANCORP, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '12757.92', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OLYBC000000', 'OLYMPIC BANCORP, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ISBFI000000', 'MIDWESTONE FINANCIAL GROUP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ISBFI000000', 'MIDWESTONE FINANCIAL GROUP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '28996.44', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('JEFBS000000', 'JEFFERSON BANCSHARES, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '15504.48', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('JEFBS000000', 'JEFFERSON BANCSHARES, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LANDB000000', 'LANDMARK BANCORP, INC.', '', 'N', '9', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LANDB000000', 'LANDMARK BANCORP, INC.', '', 'N', '9', 
    '8', '8', '0', '0', '7616.62', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LRZEN000000', 'LAURITZEN CORPORATION', '', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LRZEN000000', 'LAURITZEN CORPORATION', '', 'N', '7', 
    '6', '6', '0', '0', '97863.36', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCITB000000', 'FIRST CITIZENS BANCSHARES, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '375877.44', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCITB000000', 'FIRST CITIZENS BANCSHARES, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FINTR000000', 'FIRST INTERSTATE BANCSYSTEM, INC.', '', 'N', '9', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FINTR000000', 'FIRST INTERSTATE BANCSYSTEM, INC.', '', 'N', '9', 
    '8', '8', '0', '0', '99636.13', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRMAN000000', 'BANK FIRST NATIONAL CORPORATION', '', 'N', '8', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRMAN000000', 'BANK FIRST NATIONAL CORPORATION', '', 'N', '8', 
    '11', '11', '0', '0', '11494', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('KLEIN000000', 'KLEIN FINANCIAL, INC.', '', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('KLEIN000000', 'KLEIN FINANCIAL, INC.', '', 'N', '7', 
    '6', '6', '0', '0', '22511.64', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LKLND000000', 'LAKELAND BANCORP, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LKLND000000', 'LAKELAND BANCORP, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '48829.88', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PRVFH000000', 'PROVIDENT FINANCIAL HOLDINGS, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PRVFH000000', 'PROVIDENT FINANCIAL HOLDINGS, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '9656', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STBCI000000', 'S&T BANCORP, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '64755.24', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STBCI000000', 'S&T BANCORP, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FIFTH000000', 'FIFTH THIRD BANCORP', '', 'N', '6', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FIFTH000000', 'FIFTH THIRD BANCORP', '', 'N', '6', 
    '5', '5', '0', '0', '1667178.12', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FIRCZ000000', 'FIRST CITIZENS BANCSHARES, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '17369.76', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FIRCZ000000', 'FIRST CITIZENS BANCSHARES, INC.', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCMMN000000', 'FIRST COMMONWEALTH FINANCIAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '67962.73', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCMMN000000', 'FIRST COMMONWEALTH FINANCIAL CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TCFFI000000', 'TCF FINANCIAL CORPORATION', '', 'N', '9', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TCFFI000000', 'TCF FINANCIAL CORPORATION', '', 'N', '9', 
    '8', '8', '0', '0', '273274.43', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TRUST000000', 'TRUSTMARK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TRUST000000', 'TRUSTMARK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '129328.54', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('REPBC000000', 'REPUBLIC BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('REPBC000000', 'REPUBLIC BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '67679.26', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('IBTBC000000', 'ISABELLA BANK CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('IBTBC000000', 'ISABELLA BANK CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '15979.04', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('IONIA000000', 'INDEPENDENT BANK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('IONIA000000', 'INDEPENDENT BANK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '28968.17', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INTNL000000', 'INTERNATIONAL BANCSHARES CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '186773.64', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('INTNL000000', 'INTERNATIONAL BANCSHARES CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STFLE000001', 'STIFEL FINANCIAL CORP.', '', 'N', '5', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STFLE000001', 'STIFEL FINANCIAL CORP.', '', 'N', '5', 
    '5', '5', '0', '0', '213973.8', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DSFIN000000', 'DISCOVER FINANCIAL SERVICES', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DSFIN000000', 'DISCOVER FINANCIAL SERVICES', '', 'N', '6', 
    '6', '6', '0', '0', '1256835.12', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ESTBC000000', 'EASTERN BANK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ESTBC000000', 'EASTERN BANK CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '105321.81', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTLN000000', 'THE FIRST BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTLN000000', 'THE FIRST BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '16643', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SHRBN000000', 'SHORE BANCSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('SHRBN000000', 'SHORE BANCSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '14389.98', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTLI000000', 'THE FIRST OF LONG ISLAND CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '42507.6', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTLI000000', 'THE FIRST OF LONG ISLAND CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CIBCC000016', 'CIBC BANCORP USA, INC.', '', 'N', 'NR', 
    '10', '10', '0', '0', '459339.98', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CIBCC000016', 'CIBC BANCORP USA, INC.', '', 'N', 'NR', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNNBK000000', 'GUARANTY BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNNBK000000', 'GUARANTY BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '35762.32', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNTR1000000', 'CENTRE 1 BANCORP, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNTR1000000', 'CENTRE 1 BANCORP, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '9235.16', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PROVI000000', 'PROVIDENT FINANCIAL SERVICES, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PROVI000000', 'PROVIDENT FINANCIAL SERVICES, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '96701.88', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CENTR000000', 'CENTRAL BANCOMPANY', '', 'N', '7', 
    '7', '7', '0', '0', '182273.04', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CENTR000000', 'CENTRAL BANCOMPANY', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNTBS000000', 'CENTRAL BANCSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '26484.26', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CNTBS000000', 'CENTRAL BANCSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITFG000000', 'CITIZENS FINANCIAL GROUP, INC.', '', 'N', '8', 
    '7', '7', '0', '0', '1605724.68', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITFG000000', 'CITIZENS FINANCIAL GROUP, INC.', '', 'N', '8', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RABOB000008', 'UTRECHT - AMERICA HOLDINGS, INC.', '', 'N', '10', 
    '13', '13', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RABOB000008', 'UTRECHT - AMERICA HOLDINGS, INC.', '', 'N', '10', 
    '13', '13', '0', '0', '169819.2', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITIG000000', 'CITIGROUP INC.', 'Y', 'N', '8', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITIG000000', 'CITIGROUP INC.', 'Y', 'N', '8', 
    '6', '6', '0', '0', '20934960', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CTHLD000000', 'CITY HOLDING COMPANY', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CTHLD000000', 'CITY HOLDING COMPANY', '', 'N', '8', 
    '8', '8', '0', '0', '46630.32', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CBINC000000', 'COMMERCE BANCSHARES, INC.', '', 'N', '4', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CBINC000000', 'COMMERCE BANCSHARES, INC.', '', 'N', '4', 
    '5', '5', '0', '0', '308960.76', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('1SOUR000000', '1ST SOURCE CORPORATION', '', 'N', '7', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('1SOUR000000', '1ST SOURCE CORPORATION', '', 'N', '7', 
    '6', '6', '0', '0', '76175.28', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ACNBC000000', 'ACNB CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ACNBC000000', 'ACNB CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '14499.87', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ALPCO000000', 'ALPINE BANKS OF COLORADO', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ALPCO000000', 'ALPINE BANKS OF COLORADO', '', 'N', '8', 
    '8', '8', '0', '0', '26463.91', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMARL000000', 'AMARILLO NATIONAL BANCORP INC.', '', 'N', '6', 
    '6', '6', '0', '0', '63959.16', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMARL000000', 'AMARILLO NATIONAL BANCORP INC.', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBNKS000000', 'FIRST BANKS INC.', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBNKS000000', 'FIRST BANKS INC.', '', 'N', '7', 
    '8', '8', '0', '0', '49937.8', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCMBS000000', 'FIRST COMMUNITY BANCSHARES, INC.', '', 'N', '8', 
    '10', '10', '0', '0', '27366.13', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCMBS000000', 'FIRST COMMUNITY BANCSHARES, INC.', '', 'N', '8', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRFIN000000', 'FIRST FINANCIAL BANCORP.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRFIN000000', 'FIRST FINANCIAL BANCORP.', '', 'N', '9', 
    '9', '9', '0', '0', '79507.34', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NTRUS000000', 'NORTHERN TRUST CORPORATION', '', 'N', '3', 
    '4', '4', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NTRUS000000', 'NORTHERN TRUST CORPORATION', '', 'N', '3', 
    '4', '4', '0', '0', '1322869.94', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NWIND000000', 'NORTHWEST INDIANA BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NWIND000000', 'NORTHWEST INDIANA BANCORP', '', 'N', '8', 
    '9', '9', '0', '0', '9778.12', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTKY000000', 'FIRST KEYSTONE CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTKY000000', 'FIRST KEYSTONE CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '10734.46', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LRZEN000003', 'FIRST NATIONAL OF NEBRASKA, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LRZEN000003', 'FIRST NATIONAL OF NEBRASKA, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '195928.7', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FTENN000000', 'FIRST HORIZON NATIONAL CORPORATION', '', 'N', '10', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FTENN000000', 'FIRST HORIZON NATIONAL CORPORATION', '', 'N', '10', 
    '11', '11', '0', '0', '217105.2', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NATCN000000', 'NATIONAL CONSUMER COOPERATIVE BANK', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NATCN000000', 'NATIONAL CONSUMER COOPERATIVE BANK', '', 'N', '9', 
    '9', '9', '0', '0', '30258.47', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NEBCP000000', 'NEB CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NEBCP000000', 'NEB CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '48492.72', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITGR000000', 'CIT GROUP INC.', '', 'N', '9', 
    '7', '7', '0', '0', '812279.28', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CITGR000000', 'CIT GROUP INC.', '', 'N', '9', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GOLDS000000', 'THE GOLDMAN SACHS GROUP, INC.', 'Y', 'N', '7', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GOLDS000000', 'THE GOLDMAN SACHS GROUP, INC.', 'Y', 'N', '7', 
    '5', '5', '0', '0', '9384600', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CAPON000000', 'CAPITAL ONE FINANCIAL CORPORATION', 'Y', 'N', '8', 
    '7', '7', '0', '0', '4053149.64', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CAPON000000', 'CAPITAL ONE FINANCIAL CORPORATION', 'Y', 'N', '8', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BCFSC000001', 'BANCFIRST CORPORATION', '', 'N', '5', 
    '6', '6', '0', '0', '85279.08', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BCFSC000001', 'BANCFIRST CORPORATION', '', 'N', '5', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PCFCP000000', 'BANK OF HAWAII CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '144042.12', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PCFCP000000', 'BANK OF HAWAII CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BMNTR000005', 'BMO FINANCIAL CORP.', '', 'N', '6', 
    '7', '7', '0', '0', '1536044.76', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BMNTR000005', 'BMO FINANCIAL CORP.', '', 'N', '6', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ALRUS000000', 'ALERUS FINANCIAL CORPORATION', '', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ALRUS000000', 'ALERUS FINANCIAL CORPORATION', '', 'N', '10', 
    '9', '9', '0', '0', '13847.24', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMBNK000000', 'AMBANK CO., INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMBNK000000', 'AMBANK CO., INC.', '', 'N', '9', 
    '9', '9', '0', '0', '11855.47', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FISHB000000', 'FISHBACK FINANCIAL CORPORATION', '', 'N', '7', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FISHB000000', 'FISHBACK FINANCIAL CORPORATION', '', 'N', '7', 
    '9', '9', '0', '0', '23910.48', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('METBG000000', 'BYLINE BANCORP, INC.', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('METBG000000', 'BYLINE BANCORP, INC.', '', 'N', '8', 
    '9', '9', '0', '0', '42083.69', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CULEN000000', 'CULLEN/FROST BANKERS, INC.', '', 'N', '5', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CULEN000000', 'CULLEN/FROST BANKERS, INC.', '', 'N', '5', 
    '5', '5', '0', '0', '316540.56', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FREMO000000', 'FREMONT BANCORPORATION', '', 'N', '9', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FREMO000000', 'FREMONT BANCORPORATION', '', 'N', '9', 
    '8', '8', '0', '0', '29833.65', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WESBC000000', 'WESBANCO, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WESBC000000', 'WESBANCO, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '88666.16', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WSFLD000000', 'WESTERN NEW ENGLAND BANCORP, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WSFLD000000', 'WESTERN NEW ENGLAND BANCORP, INC.', '', 'N', '9', 
    '9', '9', '0', '0', '25380.52', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PARKN000000', 'PARK NATIONAL CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PARKN000000', 'PARK NATIONAL CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '75214.37', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PELCN000000', 'STARK BANK GROUP LTD.', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PELCN000000', 'STARK BANK GROUP LTD.', '', 'N', '8', 
    '9', '9', '0', '0', '6140.97', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRMER000000', 'FARMERS & MERCHANTS INVESTMENT, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRMER000000', 'FARMERS & MERCHANTS INVESTMENT, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '38879.06', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FARMR000000', 'FARMERS CAPITAL BANK CORPORATION', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FARMR000000', 'FARMERS CAPITAL BANK CORPORATION', '', 'N', '7', 
    '8', '8', '0', '0', '21268.83', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBUSY000000', 'FIRST BUSEY CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBUSY000000', 'FIRST BUSEY CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '68931.5', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCTBC000000', 'CIVISTA BANCSHARES, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FCTBC000000', 'CIVISTA BANCSHARES, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '17251.3', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMTRU000000', 'ATBANCORP, INC.', '', 'N', '10', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMTRU000000', 'ATBANCORP, INC.', '', 'N', '10', 
    '11', '11', '0', '0', '10107.04', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ASSAB000000', 'ASSABET VALLEY BANCORP.', '', 'N', '11', 
    '10', '10', '0', '0', '13296.91', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ASSAB000000', 'ASSABET VALLEY BANCORP.', '', 'N', '11', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WABAN000000', 'WESTERN ALLIANCE BANCORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('WABAN000000', 'WESTERN ALLIANCE BANCORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '212184.39', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRLIN000000', 'FRANKLIN FINANCIAL SERVICES CORPORATION', '', 'N', '9', 
    '10', '10', '0', '0', '11674.08', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FRLIN000000', 'FRANKLIN FINANCIAL SERVICES CORPORATION', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MBFIN000000', 'MB FINANCIAL, INC.', '', 'N', '10', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MBFIN000000', 'MB FINANCIAL, INC.', '', 'N', '10', 
    '8', '8', '0', '0', '214665.99', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TXCBS000000', 'TEXAS CAPITAL BANCSHARES, INC.', 'Y', 'N', '10', 
    '10', '10', '0', '0', '240175.65', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TXCBS000000', 'TEXAS CAPITAL BANCSHARES, INC.', 'Y', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FISEC000000', 'FIRST SECURITY BANCORP', '', 'N', '5', 
    '5', '5', '0', '0', '131082.36', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FISEC000000', 'FIRST SECURITY BANCORP', '', 'N', '5', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MTAWA000000', 'MACATAWA BANK CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MTAWA000000', 'MACATAWA BANK CORPORATION', '', 'N', '8', 
    '8', '8', '0', '0', '19028.46', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NREGI000001', 'REGIONS FINANCIAL CORPORATION', 'Y', 'N', '8', 
    '6', '6', '0', '0', '1333302.36', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NREGI000001', 'REGIONS FINANCIAL CORPORATION', 'Y', 'N', '8', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HTNCO000000', 'HOMETOWN COMMUNITY BANCORP, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HTNCO000000', 'HOMETOWN COMMUNITY BANCORP, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '20552.64', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MBTFI000000', 'MBT FINANCIAL CORP.', '', 'N', '6', 
    '7', '7', '0', '0', '15918.96', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MBTFI000000', 'MBT FINANCIAL CORP.', '', 'N', '6', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GWEBA000000', 'GREAT WESTERN BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '112189.22', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('GWEBA000000', 'GREAT WESTERN BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CBKTR000000', 'COMMUNITY BANKERS TRUST CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '13640.33', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CBKTR000000', 'COMMUNITY BANKERS TRUST CORPORATION', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CTRST000000', 'CENTERSTATE BANK CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CTRST000000', 'CENTERSTATE BANK CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '68469.83', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RCBBK000000', 'RCB HOLDING COMPANY, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RCBBK000000', 'RCB HOLDING COMPANY, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '24783.66', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RIVAL000000', 'RIVER VALLEY BANCORPORATION, INC.', '', 'N', '13', 
    '13', '13', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('RIVAL000000', 'RIVER VALLEY BANCORPORATION, INC.', '', 'N', '13', 
    '13', '13', '0', '0', '5152.48', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MDLND000000', 'MIDLAND STATES BANCORP, INC.', '', 'N', '11', 
    '12', '12', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MDLND000000', 'MIDLAND STATES BANCORP, INC.', '', 'N', '11', 
    '12', '12', '0', '0', '26719.12', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CCBFC000000', 'CCB FINANCIAL CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '14435.76', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CCBFC000000', 'CCB FINANCIAL CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNCCR000000', 'BNCCORP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '9315.12', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BNCCR000000', 'BNCCORP, INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NORBA000000', 'NORWAY BANCORP, MHC', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NORBA000000', 'NORWAY BANCORP, MHC', '', 'N', '7', 
    '7', '7', '0', '0', '19103.64', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTFN000000', 'FIRST FINANCIAL CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '45310.08', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FSTFN000000', 'FIRST FINANCIAL CORPORATION', '', 'N', '6', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FMIDW000000', 'FIRST MIDWEST BANCORP, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FMIDW000000', 'FIRST MIDWEST BANCORP, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '122112.87', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FHOLD000000', 'FIRSTBANK HOLDING COMPANY', '', 'N', '5', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FHOLD000000', 'FIRSTBANK HOLDING COMPANY', '', 'N', '5', 
    '5', '5', '0', '0', '182148', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FLAGS000000', 'FLAGSTAR BANCORP, INC.', 'Y', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FLAGS000000', 'FLAGSTAR BANCORP, INC.', 'Y', 'N', '10', 
    '9', '9', '0', '0', '151575.82', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CLAIB000004', 'GREEN BANCORP, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '40609.58', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('CLAIB000004', 'GREEN BANCORP, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PREFB000000', 'PREMIER FINANCIAL BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('PREFB000000', 'PREMIER FINANCIAL BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '15906.99', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OHNWD000000', 'OHNWARD BANCSHARES, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('OHNWD000000', 'OHNWARD BANCSHARES, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '15614.61', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MIDBI000000', 'MIDLAND BANCSHARES, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('MIDBI000000', 'MIDLAND BANCSHARES, INC.', '', 'N', '10', 
    '9', '9', '0', '0', '10997.58', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMENC000000', 'AMES NATIONAL CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('AMENC000000', 'AMES NATIONAL CORPORATION', '', 'N', '6', 
    '6', '6', '0', '0', '19551.6', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LINCB000000', 'LINCOLN BANCORP', '', 'N', '12', 
    '13', '13', '0', '0', '0', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('LINCB000000', 'LINCOLN BANCORP', '', 'N', '12', 
    '13', '13', '0', '0', '6213.76', 
    '0', 'Automated-2', 'DIPESH ADHIKARI', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BRGHI000001', 'BRAND GROUP HOLDINGS, INC.', '', 'N', '13', 
    '13', '13', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BRGHI000001', 'BRAND GROUP HOLDINGS, INC.', '', 'N', '13', 
    '13', '13', '0', '0', '15386.48', 
    '0', 'Automated-2', 'ISABELLE NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TRCNB000000', 'TRI CITY BANKSHARES CORPORATION', '', 'N', '7', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('TRCNB000000', 'TRI CITY BANKSHARES CORPORATION', '', 'N', '7', 
    '8', '8', '0', '0', '15825.15', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STRLN000000', 'STERLING BANCSHARES, INC.', '', 'N', '11', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STRLN000000', 'STERLING BANCSHARES, INC.', '', 'N', '11', 
    '9', '9', '0', '0', '14015.54', 
    '0', 'Automated-2', 'ISABELLE S NANA', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ORTFG000000', 'OFG BANCORP', 'Y', 'N', '10', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('ORTFG000000', 'OFG BANCORP', 'Y', 'N', '10', 
    '9', '9', '0', '0', '93978.61', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HILLT000000', 'HILLTOP HOLDINGS INC.', '', 'N', '7', 
    '7', '7', '0', '0', '194849.52', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HILLT000000', 'HILLTOP HOLDINGS INC.', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BUINC000000', 'BANKUNITED, INC.', '', 'N', '9', 
    '7', '7', '0', '0', '353604.48', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BUINC000000', 'BANKUNITED, INC.', '', 'N', '9', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BSHBC000000', 'BERKSHIRE HILLS BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BSHBC000000', 'BERKSHIRE HILLS BANCORP, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '103135.12', 
    '0', 'Automated-2', 'DAVID SHERMAN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STBFC000000', 'STATE BANK FINANCIAL CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '0', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('STBFC000000', 'STATE BANK FINANCIAL CORPORATION', '', 'N', '7', 
    '7', '7', '0', '0', '65496.72', 
    '0', 'Automated-2', 'DAVID A KUEHN', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DMCMB000000', 'DIME COMMUNITY BANCSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DMCMB000000', 'DIME COMMUNITY BANCSHARES, INC.', '', 'N', '10', 
    '10', '10', '0', '0', '59722.19', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FPTCI000000', 'BANC OF CALIFORNIA, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FPTCI000000', 'BANC OF CALIFORNIA, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '106035.05', 
    '0', 'Automated-2', 'MATTHEW DALE', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BBCNB000000', 'HOPE BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BBCNB000000', 'HOPE BANCORP, INC.', '', 'N', '8', 
    '8', '8', '0', '0', '158523.97', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNCOF000000', 'UNITED COMMUNITY FINANCIAL CORP.', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('UNCOF000000', 'UNITED COMMUNITY FINANCIAL CORP.', '', 'N', '9', 
    '9', '9', '0', '0', '29642.8', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBFIN000000', 'FB FINANCIAL CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('FBFIN000000', 'FB FINANCIAL CORPORATION', '', 'N', '9', 
    '9', '9', '0', '0', '48910.07', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BCBBA000000', 'BCB BANCORP, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BCBBA000000', 'BCB BANCORP, INC.', '', 'N', '11', 
    '11', '11', '0', '0', '14116.32', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HOTWN000000', 'HOMETOWN BANC CORP.', '', 'N', '5', 
    '5', '5', '0', '0', '16369.32', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('HOTWN000000', 'HOMETOWN BANC CORP.', '', 'N', '5', 
    '5', '5', '0', '0', '0', 
    '0', 'Automated-2', 'CHRISTOPHER R EDMONSTON', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DACBA000000', 'DACOTAH BANKS, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '29290.03', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('DACBA000000', 'DACOTAH BANKS, INC.', '', 'N', '9', 
    '10', '10', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NABNH000000', 'NATIONAL BANK HOLDINGS CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('NABNH000000', 'NATIONAL BANK HOLDINGS CORPORATION', '', 'N', '8', 
    '9', '9', '0', '0', '51828.7', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BHBIN000000', 'BLUE HILLS BANCORP, INC.', 'Y', 'N', '10', 
    '8', '8', '0', '0', '0', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
Insert into RISKNET_IR_LIMITS_VIEWDETAIL
   ("CP ID", "CP Name", "Exclude", "Watchlist", "Current IR", 
    "New Framework IR (1-20)", "New Final IR(1-20)", "Current PFE", "Current Limit", "New Framework Limit", 
    "Final PFE Limit", "New Assigning Method", "Assigned Analyst", "IR Adjusted", "Limit Adjusted")
 Values
   ('BHBIN000000', 'BLUE HILLS BANCORP, INC.', 'Y', 'N', '10', 
    '8', '8', '0', '0', '42689.46', 
    '0', 'Automated-2', 'POOJA CHAUDHARY', 'N', 'N');
COMMIT;
