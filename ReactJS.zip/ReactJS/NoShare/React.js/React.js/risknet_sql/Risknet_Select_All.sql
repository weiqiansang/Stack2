SELECT sec.sctr_id AS sectorid,smry.ir_lmts_smry_oid AS sum_oid,smry.per AS "Review Period", 
sec.sctr_nme AS "Sector",
smry.as_of_dt AS "Financials As Of Date",
COUNT (DISTINCT dtls.ctrpty_oid) AS "# of Counterparties", NVL (num_adj, 0) as "Adjusted",
case when (smry.stat='U') then 'Unassigned'
when (smry.stat='A') then 'Assigned'
when (smry.stat='P') then 'In-Process'
when (smry.stat='F') then 'Approved' end "Status"
FROM ir_lmts_smry smry,
ir_lmts_smry_dtls dtls,
sctr sec,
(SELECT DISTINCT ir_lmts_smry_oid,
COUNT (DISTINCT ctrpty_oid) num_adj
FROM ir_lmts_smry_dtls
WHERE (lmt_anl_adjd_flg = 'Y' or ir_anl_adjm is not null)
GROUP BY ir_lmts_smry_oid) dtls2
WHERE smry.ir_lmts_smry_oid = dtls.ir_lmts_smry_oid
AND smry.sctr_id = sec.sctr_id
AND sec.actv_stat = 'A'
AND dtls2.ir_lmts_smry_oid = dtls.ir_lmts_smry_oid
GROUP BY smry.per,sec.sctr_nme,sec.sctr_id,smry.as_of_dt,
num_adj,smry.stat,smry.ir_lmts_smry_oid 
order by smry.as_of_dt desc
