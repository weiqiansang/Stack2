select c.ctrpty_id as "CP ID",
c.ctrpty_nme as "CP Name",
d.XCLD_FLG As "Exclude",
d.WCH_LST_FLG as "Watchlist",
Case when ( d.CURR_INTL_RSK_RTG is null) then 'NR' else to_char(d.CURR_INTL_RSK_RTG) end as "Current IR",
d.MDL_INTL_RSK_RTG as "New Framework IR (1-20)",
d.FNL_INTL_RSK_RTG as "New Final IR(1-20)",
d.MAX_POTL_EXPO as "Current PFE",d.CURR_FNL_LMT as "Current Limit",
d.CALC_MDL_LMT as "New Framework Limit",
d.NEW_LMT as "Final PFE Limit", d.NEW_LMT_MTHD as "New Assigning Method", 
d.ASGD_ANL as "Assigned Analyst", 
case when (d.IR_ANL_ADJM is not null) then 'Y' else 'N' end as "IR Adjusted",case when (d.LMT_ANL_ADJD_FLG is not null) then 'Y' else 'N' end as "Limit Adjusted"
from ir_lmts_smry_dtls d, CTRPTY c
where d.ctrpty_oid = c.ctrpty_oid
and d.ir_lmts_smry_oid = 1258

--You need to change this ID, which you get in previous sql(smry.ir_lmts_smry_oid)
