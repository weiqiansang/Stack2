SET DEFINE OFF;
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '1628', '2018Q3', 'Credit Union', '30-SEP-18', 
    '662', '7', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '1632', '2018Q3', 'Mortgage Bank', '30-SEP-18', 
    '580', '98', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '1610', '2018Q3', 'U.S. Bank Scorecard', '30-SEP-18', 
    '1716', '16', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '1530', '2018Q2', 'Credit Union', '30-JUN-18', 
    '657', '9', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '1558', '2018Q2', 'Mortgage Bank', '30-JUN-18', 
    '576', '84', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('7', '1546', '2018Q2', 'U.S. Bank Holding Company Scorecard', '30-JUN-18', 
    '235', '1', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '1518', '2018Q2', 'U.S. Bank Scorecard', '30-JUN-18', 
    '1727', '14', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '1378', '2018Q1', 'Credit Union', '31-MAR-18', 
    '655', '1', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '1432', '2018Q1', 'Mortgage Bank', '31-MAR-18', 
    '582', '112', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '1353', '2018Q1', 'U.S. Bank Scorecard', '31-MAR-18', 
    '1727', '11', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('9', '1493', '2017', 'Broker Dealer', '31-DEC-17', 
    '62', '10', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '1204', '2017Q4', 'Credit Union', '31-DEC-17', 
    '650', '2', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '1343', '2017Q4', 'Mortgage Bank', '31-DEC-17', 
    '586', '126', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '1050', '2017Q3', 'Credit Union', '30-SEP-17', 
    '650', '2', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '1096', '2017Q3', 'Mortgage Bank', '30-SEP-17', 
    '589', '129', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '1036', '2017Q3', 'U.S. Bank Scorecard', '30-SEP-17', 
    '1751', '8', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '946', '2017Q2', 'Mortgage Bank', '30-JUN-17', 
    '579', '106', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '846', '2017Q2', 'U.S. Bank Scorecard', '30-JUN-17', 
    '1751', '11', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '723', '2017Q1', 'Credit Union', '31-MAR-17', 
    '643', '5', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '771', '2017Q1', 'Mortgage Bank', '31-MAR-17', 
    '568', '111', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '700', '2017Q1', 'U.S. Bank Scorecard', '31-MAR-17', 
    '1759', '15', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('9', '882', '2016', 'Broker Dealer', '31-DEC-16', 
    '65', '20', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '567', '2016Q4', 'Credit Union', '31-DEC-16', 
    '629', '2', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '695', '2016Q4', 'Mortgage Bank', '31-DEC-16', 
    '26', '6', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '688', '2016Q4', 'Mortgage Bank', '31-DEC-16', 
    '571', '112', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('7', '612', '2016Q4', 'U.S. Bank Holding Company Scorecard', '31-DEC-16', 
    '244', '5', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '539', '2016Q4', 'U.S. Bank Scorecard', '31-DEC-16', 
    '1765', '24', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('9', '854', '2016', 'Broker Dealer', '30-SEP-16', 
    '2', '1', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '432', '2016Q3', 'Credit Union', '30-SEP-16', 
    '641', '2', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '481', '2016Q3', 'Mortgage Bank', '30-SEP-16', 
    '34', '3', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '468', '2016Q3', 'Mortgage Bank', '30-SEP-16', 
    '568', '114', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('7', '444', '2016Q3', 'U.S. Bank Holding Company Scorecard', '30-SEP-16', 
    '239', '5', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '415', '2016Q3', 'U.S. Bank Scorecard', '30-SEP-16', 
    '1777', '47', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '348', '2016Q2', 'Credit Union', '30-JUN-16', 
    '636', '4', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '381', '2016Q2', 'Mortgage Bank', '30-JUN-16', 
    '28', '5', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '363', '2016Q2', 'Mortgage Bank', '30-JUN-16', 
    '567', '129', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '351', '2016Q2', 'U.S. Bank Scorecard', '30-JUN-16', 
    '1788', '25', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('9', '303', '2016', 'Broker Dealer', '31-MAR-16', 
    '3', '2', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '268', '2016Q1', 'Credit Union', '31-MAR-16', 
    '628', '4', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '288', '2016Q1', 'Mortgage Bank', '31-MAR-16', 
    '559', '145', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('7', '275', '2016Q1', 'U.S. Bank Holding Company Scorecard', '31-MAR-16', 
    '243', '3', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '264', '2016Q1', 'U.S. Bank Scorecard', '31-MAR-16', 
    '1802', '23', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('9', '302', '2015', 'Broker Dealer', '31-DEC-15', 
    '69', '39', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '224', '2015Q4', 'Credit Union', '31-DEC-15', 
    '625', '5', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '249', '2015Q4', 'Mortgage Bank', '31-DEC-15', 
    '560', '202', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('7', '229', '2015Q4', 'U.S. Bank Holding Company Scorecard', '31-DEC-15', 
    '248', '12', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '223', '2015Q4', 'U.S. Bank Scorecard', '31-DEC-15', 
    '1709', '39', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('4', '192', '2015Q3', 'Credit Union', '30-SEP-15', 
    '623', '5', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('7', '197', '2015Q3', 'U.S. Bank Holding Company Scorecard', '30-SEP-15', 
    '237', '18', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('2', '203', '2015Q3', 'U.S. Bank Scorecard', '30-SEP-15', 
    '1813', '60', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('8', '168', '2015Q2', 'Mortgage Bank', '30-JUN-15', 
    '582', '526', 'Approved');
Insert into RISKNET_IR_LIMITS
   (SECTORID, SUM_OID, "Review Period", "Sector", "Financials As Of Date", 
    "# of Counterparties", "Adjusted", "Status")
 Values
   ('9', '162', '2014', 'Broker Dealer', '31-DEC-14', 
    '3', '3', 'Assigned');
COMMIT;
