package com.fanniemae.customersolutions.risknet.gui.web.util;

import java.util.regex.Pattern;

import com.fanniemae.util.FMEnvironmentMgr;

public class ValidationUtil {
	private static final Pattern notWhitelistPattern1 = Pattern.compile(getNonWhiteListSet1());
	private static final Pattern notWhitelistPattern2 = Pattern.compile(getNonWhiteListSet2());
	private static final Pattern notWhitelistPattern3 = Pattern.compile(getNonWhiteListSet3());
	
	private static String getNonWhiteListSet1() {
		/*
		FMEnvironmentMgr.Key filterKey = new FMEnvironmentMgr.Key("regexp.pattern.nonwhitelist.set1");
		System.out.println("NonWhitelist pattern1 : "+(String) FMEnvironmentMgr.sharedInstance().valueForKey(filterKey));		
		return ((String) FMEnvironmentMgr.sharedInstance().valueForKey(filterKey));	
		*/
		//in DB:[^A-Za-z0-9\\.\s:\-#,+()&@]+
		return "[^A-Za-z0-9\\.\\s:\\-#,+()&@]+";
	}
	
	private static String getNonWhiteListSet2() {
		/*
		FMEnvironmentMgr.Key filterKey = new FMEnvironmentMgr.Key("regexp.pattern.nonwhitelist.set2");
		System.out.println("NonWhitelist pattern2 : "+(String) FMEnvironmentMgr.sharedInstance().valueForKey(filterKey));		
		return ((String) FMEnvironmentMgr.sharedInstance().valueForKey(filterKey));	
		*/
		//in DB:[^A-Za-z0-9\\.\s:\-#,]+
		return "[^A-Za-z0-9\\.\\s:\\-#,]+";
	}

	private static String getNonWhiteListSet3() {
		/*
		FMEnvironmentMgr.Key filterKey = new FMEnvironmentMgr.Key("regexp.pattern.nonwhitelist.set3");
		System.out.println("NonWhitelist pattern3 : "+(String) FMEnvironmentMgr.sharedInstance().valueForKey(filterKey));		
		return ((String) FMEnvironmentMgr.sharedInstance().valueForKey(filterKey));		
		*/
		//in DB:[^A-Za-z0-9\\.\s:\-#,+()&@/~']+
		return "[^A-Za-z0-9\\.\\s:\\-#,+()&@/~']+";
	}
	
	/**
	 * Filter outs any characters matching the pattern [^A-Za-z0-9\\.\s:\-#,+()&@]+ from the input string
	 * @param input
	 * @return
	 */
	public static String filterInvalidCharsSet1(String input) {
		if(input != null){
			String output = notWhitelistPattern1.matcher( input ).replaceAll("");
			System.out.println("ValidationUtil::filterInvalidCharsSet1::input - "+input+"	output - "+output);
			return output;
		}
		else{
			return input;
		}
	}	
	
	/**
	 * Filter outs any characters matching the pattern [^A-Za-z0-9\\.\s:\-#,]+ from the input string
	 * @param input
	 * @return
	 */
	public static String filterInvalidCharsSet2(String input) {
		if(input != null){
			String output = notWhitelistPattern2.matcher( input ).replaceAll("");
			System.out.println("ValidationUtil::filterInvalidCharsSet2::input - "+input+"	output - "+output);
			return output;
		}
		else{
			return input;
		}
	}	
	
	/**
	 * Filter outs any characters matching the pattern [^A-Za-z0-9\\.\s:\-#,+()&@/~']+ from the input string
	 * @param input
	 * @return
	 */
	public static String filterInvalidCharsSet3(String input) {
		if(input != null){
			String output = notWhitelistPattern3.matcher( input ).replaceAll("");
			System.out.println("ValidationUtil::filterInvalidCharsSet3::input - "+input+"	output - "+output);
			return output;
		}
		else{
			return input;
		}
	}	
}
