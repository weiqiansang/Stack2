
	// Declaring required variables
	var digits = "0123456789";
	// non-digit characters which are allowed in phone numbers
	var phoneNumberDelimiters = "()- ";
	// characters which are allowed in international phone numbers
	// (a leading + is OK)
	var validWorldPhoneChars = phoneNumberDelimiters + "+";
	// Minimum no of digits in an international phone no.
	var minDigitsInIPhoneNumber = 10;
	

	// Internal server submit to get the existing addresses of a Custodian.
	function getCustExistingAddresses(){

		if(document.forms["frmNewCustAgrmt"].custOID.value.length>0){
			// call the iframe to refresh the existing selected pools before getting the Institution address.
			if(document.forms["frmNewCustAgrmt"].agrmtTypeRadio[1].checked){
				tmpMaxPages		= "0";
				tmpPageNo		= "0";
				tmpPrevPageNo	= "0";
				tmpNxtPageNo	= "0";
				if(window.frames["poolFrame"].maxPages != undefined){
					tmpMaxPages = window.frames["poolFrame"].maxPages.value;
				}
				if(window.frames["poolFrame"].pageNo != undefined){
					tmpPageNo = window.frames["poolFrame"].pageNo.value;
				}
				if(window.frames["poolFrame"].prevPageNo != undefined){
					tmpPrevPageNo = window.frames["poolFrame"].prevPageNo.value;
				}
				if(window.frames["poolFrame"].nxtPageNo != undefined){
					tmpNxtPageNo = window.frames["poolFrame"].nxtPageNo.value;
				}

				getPools("FIRST");

				// after iframe call get the previous selected page to display
				window.frames["poolFrame"].maxPages.value = tmpMaxPages; 
				window.frames["poolFrame"].pageNo.value = tmpPageNo;
				window.frames["poolFrame"].prevPageNo.value = tmpPrevPageNo;
				window.frames["poolFrame"].nxtPageNo.value = tmpNxtPageNo;
			}

			document.forms["frmNewCustAgrmt"].ACTION.value="CUSTEXISTINGADDR";
			setSecondFormFields();
			//var strAction = "doccustagmt?ACTION=CUSTEXISTINGADDR&lenderOID=<%=lenderOID%>&agmtOID=<%=agmtOID%>&custAliasOID="+document.forms["frmSubmit"].custAliasOID.value;
			//document.forms["frmSubmit"].action = strAction;

			document.forms["frmSubmit"].submit();

		} else {
			document.forms["frmNewCustAgrmt"].custAddrTypeRadio[1].checked = true;
			showCustAddrDiv();
			alert("Select Institution#");
		}

	}


	// set all the main form fields to second form fields inorder to submit to the server 
	// to get the Custodian existing address.
	function setSecondFormFields(){

		document.forms["frmSubmit"].agrmtDate.value = document.forms["frmNewCustAgrmt"].agrmtDate.value;
		if(document.forms["frmNewCustAgrmt"].agmtID!=null
			&& document.forms["frmNewCustAgrmt"].agmtID.value!=null){
			document.forms["frmSubmit"].agmtID.value = document.forms["frmNewCustAgrmt"].agmtID.value;
		}
		document.forms["frmSubmit"].agmtOID.value = document.forms["frmNewCustAgrmt"].agmtOID.value;
		if( document.forms["frmNewCustAgrmt"].agrmtTypeRadio[0].checked){
			document.forms["frmSubmit"].agrmtTypeRadio.value = "masterAgrmt";
		} else {
			document.forms["frmSubmit"].agrmtTypeRadio.value = "poolAgrmt";
		}
		document.forms["frmSubmit"].lenderOID.value = document.forms["frmNewCustAgrmt"].lenderOID.value;
		document.forms["frmSubmit"].lenderID.value = document.forms["frmNewCustAgrmt"].lenderID.value;
		document.forms["frmSubmit"].lenderName.value = document.forms["frmNewCustAgrmt"].lenderName.value;
		document.forms["frmSubmit"].lenderAddr.value = document.forms["frmNewCustAgrmt"].lenderAddr.value;
		document.forms["frmSubmit"].lenderCity.value = document.forms["frmNewCustAgrmt"].lenderCity.value;
		document.forms["frmSubmit"].lenderState.value = document.forms["frmNewCustAgrmt"].lenderState.value;
		document.forms["frmSubmit"].lenderZip.value = document.forms["frmNewCustAgrmt"].lenderZip.value;
		document.forms["frmSubmit"].lenderSelfCust.value = document.forms["frmNewCustAgrmt"].lenderSelfCust.value;
		document.forms["frmSubmit"].selfCustAddrOID.value = document.forms["frmNewCustAgrmt"].selfCustAddrOID.value;
		document.forms["frmSubmit"].custOID.value = document.forms["frmNewCustAgrmt"].custOID.value;
		document.forms["frmSubmit"].custInstID.value = document.forms["frmNewCustAgrmt"].custInstID.value;
		document.forms["frmSubmit"].custAliasOID.value = document.forms["frmNewCustAgrmt"].custAliasOID.value;
		document.forms["frmSubmit"].custName.value = document.forms["frmNewCustAgrmt"].custName.value;		
		document.forms["frmSubmit"].idcRating.value = document.forms["frmNewCustAgrmt"].idcRating.value;
		document.forms["frmSubmit"].fitchRating.value = document.forms["frmNewCustAgrmt"].fitchRating.value;
		if(document.forms["frmNewCustAgrmt"].custAddrTypeRadio[0].checked){
			document.forms["frmSubmit"].custAddrTypeRadio.value ="custAddrExists";
		} else {
			document.forms["frmSubmit"].custAddrTypeRadio.value ="custAddrNew";
		}
		if(document.forms["frmNewCustAgrmt"].custAddrSelRadio!=null){
			if(document.forms["frmNewCustAgrmt"].custAddrSelRadio.length > 0){
				for(var i=0; i<document.forms["frmNewCustAgrmt"].custAddrSelRadio.length; i++){
					if(document.forms["frmNewCustAgrmt"].custAddrSelRadio[i].checked){
						document.forms["frmSubmit"].custAddrSelRadio.value = document.forms["frmNewCustAgrmt"].custAddrSelRadio[i].value;
					}
				}
			}
		}
		document.forms["frmSubmit"].custAddr.value = document.forms["frmNewCustAgrmt"].custAddr.value;
		document.forms["frmSubmit"].custCity.value = document.forms["frmNewCustAgrmt"].custCity.value;
		document.forms["frmSubmit"].custState.value = document.forms["frmNewCustAgrmt"].custState.value;
		document.forms["frmSubmit"].custZip.value = document.forms["frmNewCustAgrmt"].custZip.value;
		if(document.forms["frmNewCustAgrmt"].branchSelChkBox != null){
			document.forms["frmSubmit"].branchSelChkBox.value = document.forms["frmNewCustAgrmt"].branchSelChkBox.value;
		}
		if(document.forms["frmNewCustAgrmt"].poolSelChkBox != null){
			document.forms["frmSubmit"].poolSelChkBox.value = document.forms["frmNewCustAgrmt"].poolSelChkBox.value;
		}
		document.forms["frmSubmit"].selBranchTxt.value = document.forms["frmNewCustAgrmt"].selBranchTxt.value;
		document.forms["frmSubmit"].selPoolTxt.value = document.forms["frmNewCustAgrmt"].selPoolTxt.value;

		document.forms["frmSubmit"].attestedByName.value = document.forms["frmNewCustAgrmt"].attestedByName.value;
		document.forms["frmSubmit"].attestedByTitle.value = document.forms["frmNewCustAgrmt"].attestedByTitle.value;
		document.forms["frmSubmit"].custContactName.value = document.forms["frmNewCustAgrmt"].custContactName.value;
		document.forms["frmSubmit"].custContactTitle.value = document.forms["frmNewCustAgrmt"].custContactTitle.value;
		document.forms["frmSubmit"].custPhoneNo.value = document.forms["frmNewCustAgrmt"].custPhoneNo.value;
		if(window.frames["poolFrame"].pageNo != undefined){
			document.forms["frmSubmit"].pageNo.value = window.frames["poolFrame"].pageNo.value;
		}
		if(window.frames["poolFrame"].maxPages != undefined){
			document.forms["frmSubmit"].maxPages.value = window.frames["poolFrame"].maxPages.value;
		}
		document.forms["frmSubmit"].ACTION.value = "CUSTEXISTINGADDR";
		document.forms["frmSubmit"].userID.value = document.forms["frmNewCustAgrmt"].userID.value;

	}


	// unset the self custodian fields when user unchecked the self custodian check box.
	function unsetSelfCustodianFields(){
		//unset the fields for Self Custodian
		document.forms["frmNewCustAgrmt"].lenderSelfCust.checked = false;
		document.forms["frmNewCustAgrmt"].lenderSelfCust.value = "N";
		document.forms["frmNewCustAgrmt"].custInstID.value = "";
		document.forms["frmNewCustAgrmt"].custOID.value = "";
		//document.forms["frmNewCustAgrmt"].custAliasOID.value = "";
		document.forms["frmNewCustAgrmt"].custName.value = "";
		document.forms["frmNewCustAgrmt"].idcRating.value = "";
		document.forms["frmNewCustAgrmt"].fitchRating.value = "";

		document.forms["frmNewCustAgrmt"].btnCustodian.disabled = false;

		document.forms["frmNewCustAgrmt"].custAddrTypeRadio[0].checked = false;
		document.forms["frmNewCustAgrmt"].custAddrTypeRadio[0].disabled = false;
		document.forms["frmNewCustAgrmt"].custAddrTypeRadio[1].checked = true;
		showCustAddrDiv();	//enable the new address field
		document.forms["frmNewCustAgrmt"].custAddrTypeRadio[1].disabled = false;

		document.forms["frmNewCustAgrmt"].custAddr.value = "";
		document.forms["frmNewCustAgrmt"].custCity.value = "";
		document.forms["frmNewCustAgrmt"].custState.value = "";
		document.forms["frmNewCustAgrmt"].custZip.value = "";
	}


	// Lookup window to get the Institution no, name and ratings.
	function openFinderWindow(url){
	  document.forms["frmNewCustAgrmt"].custAddrTypeRadio[1].checked = true;
	  showCustAddrDiv();	//always show new address before open a Institution lookup pop up
	  var sFeatures = "location=no, menubar=no, toolbar=no, resizable=yes, scrollbars=yes, status=no, fullscreen=no, top=100, left=100, width=700, height=600" ;
	  var win = window.open(url, "FindCP", sFeatures);
	  win.focus();
	}

	// show/hide the address div tag for existing/new Institution addresses
	function showCustAddrDiv(){
		if(document.forms["frmNewCustAgrmt"].custAddrTypeRadio[0].checked){
			document.getElementById("divCustAddrExist").style.display="block";
			document.getElementById("divCustAddrNew").style.display="none";
		} else if(document.forms["frmNewCustAgrmt"].custAddrTypeRadio[1].checked){
			document.getElementById("divCustAddrExist").style.display="none";
			document.getElementById("divCustAddrNew").style.display="block";
		}
	}

	// show/hide the agreemnt div tag for master/pool level agreement
	function showAgrmtDiv(){
		if(document.forms["frmNewCustAgrmt"].agrmtTypeRadio[0].checked){
			document.getElementById("divShowMaster").style.display="block";
			document.getElementById("divShowPool").style.display="none";
		} else if(document.forms["frmNewCustAgrmt"].agrmtTypeRadio[1].checked){
			document.getElementById("divShowMaster").style.display="none";
			document.getElementById("divShowPool").style.display="block";
		}
	}


	// Check for the integer value
	function isInteger(s){   
		var i;
	    for (i = 0; i < s.length; i++) {   
	        // Check that current character is number.
	        var c = s.charAt(i);
	        if (((c < "0") || (c > "9"))) return false;
	    }
	    // All characters are numbers.
	    return true;
	}

	
	function stripCharsInBag(s, bag) {   
		var i;
	    var returnString = "";
	    // Search through string's characters one by one.
	    // If character is not in bag, append to returnString.
	    for (i = 0; i < s.length; i++) {   
	        // Check that current character isn't whitespace.
	        var c = s.charAt(i);
	        if (bag.indexOf(c) == -1) returnString += c;
	    }
	    return returnString;
	}
	

	//function for phone no validation.
	function checkInternationalPhone(strPhone){
		s=stripCharsInBag(strPhone,validWorldPhoneChars);
		return (isInteger(s) && s.length >= minDigitsInIPhoneNumber);
	}
	
	
	// show Institution description on mouse over event
	function showCustDesc(){
		var txt = "<table width='100%' height='100%' class='resultTable'>"+
	 	  			     "<tr>"+
	 	  				 "<td valign='top' class='tdLabel'>The Institution is a Federal Home Loan Bank. A regulated financial institution or a subsidiary or parent of a regulated financial institution or holding company that is subject to supervision and regulation by the Federal Deposit Insurance Corporation. the Office of Controller of the Currency of the United States. The Board of Governors of the Federal Reserve System. the Office of Thrift Supervision. or the National Credit Union Administration.</td>"
	 	  				 "</tr>"+
	 	  				"</table>";
	 	document.getElementById("showCustDesc").style.display="block";
	 	document.getElementById("showCustDesc").style.top=event.y+document.body.scrollTop;
		document.getElementById("showCustDesc").style.left=(event.x+10)+document.body.scrollLeft;
		document.getElementById("showCustDesc").style.visibility='visible';
		document.getElementById("showCustDesc").innerHTML=txt;
	}


	// hide Institution description on mouse over event
	function hideCustDesc() {
  	  	document.getElementById("showCustDesc").style.display="none";
		document.getElementById("showCustDesc").style.top=event.y+document.body.scrollTop;
		document.getElementById("showCustDesc").style.left=(event.x+10)+document.body.scrollLeft;
		document.getElementById("showCustDesc").style.visibility='hidden';
	}


	// truncate comma if it is the first char
	function getUniqueElmStr(srcOld, srcNew, srcAction) {
		var strRet = srcOld.trim();
		if(srcAction == "ADD"){
			if(srcNew != null && srcNew != "" ){
				var array = tokenize(srcNew);
				for(var i=0; i<array.length; i++){
					if(array[i] !="" && srcOld.indexOf(array[i]) == -1){
						strRet += "," + array[i];					
					}
				}

			} else {
				strRet += srcNew;
			}
		} else if(srcAction == "DELETE"){
			if(srcNew != null && srcNew != "" ){
				var array = tokenize(srcNew);
				for(var i=0; i<array.length; i++){
					if(array[i] !="" && strRet.indexOf(array[i]) != -1){
						strTmp = "";
						if( strRet.indexOf(array[i]+",") != -1 ){							
							strRet = strRet.replace(array[i]+",", "");	
						} else if( strRet.indexOf(array[i]) != -1 ){
							strRet = strRet.replace(array[i], "");
							if(strRet.charAt(strRet.length-1) == ','){
								strRet = strRet.substring(0, strRet.length-1);
							}
						}
					}
				}

			} else {
				strRet += srcNew;
			}
		}
		
		if(strRet.indexOf(",", 0) == 0){
			strRet = strRet.substring(1, strRet.length);
		}

		return strRet;
	}

	// tokenize the string for space and comma
	function tokenize(input){
		var array = input.split(',');
		var token = new Array();
		token = array;
		/*for(var i=0; i<array.length; i++){
			if(array[i] != ""){
				token.push(array[i]);
			}
		 }

		return token;*/
		return array;
	}

	// enable filters functions for branch, pools and address.
	function enableBranchFilter() {
		<!-- attachFilter(document.getElementById('tblBranches'), 1, "0,1,2,3,6"); /* indexes are starting from zero */ -->
	}

	function enablePoolFilter()	{
		<!-- attachFilter(document.getElementById('tblPools'), 1, "0,3"); /* indexes are starting from zero */ -->
	}

	function enableCustAddrFilter()	{
		<!-- attachFilter(document.getElementById('tblCustAddr'), 1, "0,1,4,5"); /* indexes are starting from zero */ -->
	}

	function hasOptions(obj) {
		if (obj!=null && obj.options!=null) { return true; }
		return false;
	}

	function sortSelect(obj) {
		var o = new Array();
		if (!hasOptions(obj)) { return; }

		for (var i=0; i<obj.options.length; i++) {
			o[o.length] = new Option( obj.options[i].text, obj.options[i].value, obj.options[i].defaultSelected, obj.options[i].selected) ;
		}

		if (o.length==0) { return; }

		o = o.sort(
			function(a,b) {
				if ((a.text+"") < (b.text+"")) { return -1; }
				if ((a.text+"") > (b.text+"")) { return 1; }
				return 0;
				}
			);

		for (var i=0; i<o.length; i++) {
			obj.options[i] = new Option(o[i].text, o[i].value, o[i].defaultSelected, o[i].selected);
		}
	}

	function moveSelectedOptions(from,to) {
		// Move them over
		if (!hasOptions(from)) { return; }
		for (var i=0; i<from.options.length; i++) {
			var o = from.options[i];
			if (o.selected) {
				if (!hasOptions(to)) {
					var index = 0;
				} else {
					var index=to.options.length;
				}
				to.options[index] = new Option( o.text, o.value, false, false);
			}
		}

		// Delete them from original
		for (var i=(from.options.length-1); i>=0; i--) {
			var o = from.options[i];
			if (o.selected) {
				from.options[i] = null;
			}
		}

		sortSelect(from);
		sortSelect(to);

		from.selectedIndex = -1;
		to.selectedIndex = -1;
	}

	// Close the Agreement window
	function closeWindow(){
		var ok = confirm("Modified data will be lost on closing the window. Do you still want to continue?");
		if ( ok ){
			self.close();
			return true;
		} else {
			return false;
		}
	}

	
	//Check for double quotes
	function checkDoubleQuotes(inputStr){
		if(inputStr != "" && inputStr.indexOf('\"') != -1){
			return false;
		} else{
			return true;
		}

	}