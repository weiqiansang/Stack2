
var lastEvalSource;

function openCPFinderWindow(url)
{
  var sFeatures = "location=no, menubar=no, toolbar=no, resizable=yes, scrollbars=yes, status=no, fullscreen=no, top=100, left=100, width=650, height=600" ;
  var win = window.open(url, "FindCP", sFeatures);
        win.focus();

}
function openMessageWindow(url)
{
  var sFeatures = "location=no, menubar=no, toolbar=no, resizable=no, scrollbars=no, status=no, fullscreen=no, top=200, left=300, width=450, height=350" ;
  var win = window.open(url, "FindCP", sFeatures);
        win.focus();

}
function stripSpaces(myObject) {
  x = myObject.value;
  while (x.substring(0,1) == ' ') x = x.substring(1);
  while (x.substring(x.length-1,x.length) == ' ') x = x.substring(0,x.length-1);
  x.replace(/^\s+/,'').replace(/\s+$/,'');  // takes care of line-feeds too. case-sensitive!!
  myObject.value = x;
}

function roundNumber(decNum){

	if (decNum==""){
		return "";
	}

	return Math.round(decNum*100)/100 ;

}

function validateDateRange(fromdate, todate)
{
  var DateFrom;
  var DateTo;
  var TodaysDate;

  //
  // CHECK IF THE DATES ARE IN VALID FORMAT, THAT IS mm/dd/yyyy
  //
  if ( (fromdate.value!="" && !isValidDate(fromdate)) ||
      (todate.value!="" && !isValidDate(todate))  )
  {
    return false;
  }

  if (fromdate.value!="")
  {
    TodaysDate = new Date();
    DateFrom = new Date(fromdate.value);
    //if(DateFrom < TodaysDate)
    //{
   //   alert(fromdate.desc + ' must be earlier than today.');
   //   return false;
   // }
  }

  if (fromdate.value=="" || todate.value=="")
  {
    return true;
  }


  DateTo = new Date(todate.value);
  if(DateTo < DateFrom)
  {
    alert(todate.desc + ' must be later than ' +fromdate.desc);
    return false;
  }

  return true;
}

function isValidDate(dateStr)
{
  //
  // CHECK IF THE DATES ARE IN VALID FORMAT, THAT IS mm/dd/yyyy
  // Reference: http://www.rgagnon.com/jsdetails/js-0063.html
  //

  var patternToFollow = /^\d{1,2}(\/|)\d{1,2}\1\d{4}$/

  if(!patternToFollow.test(dateStr.value) || dateStr.value.length!=10)
  {
    alert(dateStr.value + " : Date format incorrect. Please enter date in MM/DD/YYYY format.");
    return false;
  }
  else
  {
    var strSeparator = '/';    // find date separator
    var arrayDate = dateStr.value.split(strSeparator);  // split date into month, day, year
    // create a lookup for months not equal to Feb.
    var arrayLookup = { '01' : 31,'03' : 31, '04' : 30,'05' : 31,'06' : 30,'07' : 31,
                        '08' : 31,'09' : 30,'10' : 31,'11' : 30,'12' : 31}
    var intDay = parseInt(arrayDate[1], 10);  // important to parse to base 10 or 08 is octal!

    var intYear = parseInt(arrayDate[2]);
    var intMonth = parseInt(arrayDate[0]);

    var isValidDayMonth = false;
    var isValidYear = false;


    // check if month value and day value agree
    if(arrayLookup[arrayDate[0]] != null) {
      if(intDay <= arrayLookup[arrayDate[0]] && intDay != 0)
        isValidDayMonth =  true; //found in lookup table, good date
    }

    // check for February
    if( ((intYear % 4 == 0 && intDay <= 29) || (intYear % 4 != 0 && intDay <=28))
         && intDay !=0 && !isValidDayMonth && intMonth==2)
      isValidDayMonth =  true; //Feb. had valid number of days

    if (isValidDayMonth==true && intYear >0 && intYear<9999)
      isValidYear=true;

    //return true is its fine
    if (isValidYear && isValidDayMonth)
       return true;

  }


  alert(dateStr.value + " is not valid. Please enter date in MM/DD/YYYY format.");
  return false; // any other values, bad date
} // end function isValidDate()

function validateForm(formName,fields) {


    for (var i=0; i<fields.length; i++) {
        fieldName = eval(formName +"." + fields[i]);
		lastEvalSource = fieldName;


    if (fieldName.type == 'text' || fieldName.type == 'hidden' || fieldName.type == 'password' || fieldName.type == 'textarea') {
      stripSpaces(fieldName);
      if (fieldName.value==''){

        alert("Please enter "  + fieldName.desc);
        if (fieldName.type != 'hidden' )
          fieldName.focus();
        return false;
      }
        }

    if (fieldName.type == undefined) {
      noOfOptions = fieldName.length;
      flag = false;

      for (j=0;j<noOfOptions;j++){
        if (fieldName[j].checked ==true){
          flag = true;
          break;
        }
      }

      if (!flag) {
        alert("Please select "  + fieldName[0].desc);
        return false;
      }

        }

    var str = new String(fieldName.type);

    if (str.indexOf("select")!= -1 ) {
      if (fieldName.selectedIndex==-1 || fieldName.options[fieldName.selectedIndex].value == "")
      {
        alert("Please select " + fieldName.desc);
        fieldName.focus();
        return false;
      }
    }


    }

   return true;
}


function resetNumeric(formName,fields)
{
	for (var i=0; i<fields.length; i++) {	
		fieldName = eval(formName +"." + fields[i]);
		stripSpaces(fieldName);
		
		if (fieldName.value==0){
			fieldName.value = "";		
		}
	}
}

function resetNumericNull(formName,fields)
{
	for (var i=0; i<fields.length; i++) {	
		fieldName = eval(formName +"." + fields[i]);
		stripSpaces(fieldName);
		
		if (fieldName.value=="null"){
			fieldName.value = "";		
		}
	}
}

function validateNumeric(formName,fields) {
    for (var i=0; i<fields.length; i++) {

        fieldName = eval(formName +"." + fields[i]);
		lastEvalSource = fieldName;
        stripSpaces(fieldName);

      if (!isFloat(fieldName.value)){
        alert("Please enter a valid "  + fieldName.desc);
                                fieldName.focus();
        return false;
      }
	  else{
		  fieldName.value=roundNumber(fieldName.value);	
	  }
    }
   return true;
}

 function isDigit (c)
{
    return ((c >= "0") && (c <= "9"));
}

//------------------------------------------------------------------------------------------------

function isEmpty(s)
{
    return ((s == null) || (s.length == 0))
}
//------------------------------------------------------------------------------------------------

function isFloat (s)

{
    var i;
    var decimalPointDelimiter = "."
    var seenDecimalPoint = false;

   if (isEmpty(s))
       return true;

   if (s == decimalPointDelimiter) return false;

   // Search through string's characters one by one
   // until we find a non-numeric character.
   // When we do, return false; if we don't, return true.

   for (i = 0; i < s.length; i++)
   {
        // Check that current character is number.
       var c = s.charAt(i);

       if ((c == decimalPointDelimiter) && !seenDecimalPoint) seenDecimalPoint = true;
       else if (!isDigit(c)) return false;
   }

   // All characters are numbers.
   return true;
}
function isInteger (s)
{

var i;

if (isEmpty(s))
    return true;

   for (i = 0; i < s.length; i++)
    {
         // Check that current character is number.
         var c = s.charAt(i);
         if (!isDigit(c)) return false;
    }
// All characters are numbers.
return true;
}

function MoveUp(selectval)
    {
      if (selectval.value != '' && selectval.selectedIndex != 0)
      {
        var SelText  = selectval.options[selectval.selectedIndex].text;
        var SelValue =  selectval.options[selectval.selectedIndex].value;
    var selIndex = selectval.selectedIndex;
        selectval.options[selectval.selectedIndex].value = selectval.options[selectval.selectedIndex - 1].value;
        selectval.options[selectval.selectedIndex].text = selectval.options[selectval.selectedIndex - 1].text;
        selectval.options[selectval.selectedIndex - 1].value = SelValue;
        selectval.options[selectval.selectedIndex - 1].text  = SelText;
        selectval.options[selectval.selectedIndex - 1].selected = true;
    selectval.options[selIndex].selected = false;
      }
    }

    function MoveDown(selectval)
    {
      if (selectval.value != '' && selectval.selectedIndex != (selectval.length - 1))
      {
        var SelText = selectval.options[selectval.selectedIndex].text;
        var SelValue =  selectval.options[selectval.selectedIndex].value;
    var selIndex = selectval.selectedIndex;
        selectval.options[selectval.selectedIndex].value = selectval.options[selectval.selectedIndex + 1].value;
        selectval.options[selectval.selectedIndex].text = selectval.options[selectval.selectedIndex + 1].text;
        selectval.options[selectval.selectedIndex + 1].value  = SelValue;
        selectval.options[selectval.selectedIndex + 1].text   = SelText;
        selectval.options[selectval.selectedIndex + 1].selected = true;
    selectval.options[selIndex].selected = false;
      }
    }

    function MoveAcross(cmbFrom, cmbTo)
    {
      var toLength = cmbTo.options.length;
      var fromLength = cmbFrom.options.length;


      for(i=0;i<fromLength;i++)
      {
        if (cmbFrom.options[i].selected==true)
        {

          var opt = new Option(cmbFrom.options[i].text,cmbFrom.options[i].value);
          cmbTo.options[toLength] = opt;
          toLength = toLength+1;
        }
      }

      for(i=fromLength-1;i>=0;i--)
      {
        if (cmbFrom.options[i].selected==true)
        {
          cmbFrom.options[i]=null;
        }
      }

    }
	
function integerOnly(){
	return '0123456789'.indexOf(String.fromCharCode(event.keyCode))>-1	;
}	

function checkTextAreaLength(field,max){
   if (field.value.length > max) // if too long...trim it!
       field.value = field.value.substring(0, max);

}
function trim(inputString) {
   // Removes leading and trailing spaces from the passed string. Also removes
   // consecutive spaces and replaces it with one space.
   if (typeof inputString != "string") { return inputString; }
   var retValue = inputString;
   var ch = retValue.substring(0, 1);
   while (ch == " ") { // Check for spaces at the beginning of the string
      retValue = retValue.substring(1, retValue.length);
      ch = retValue.substring(0, 1);
   }
   ch = retValue.substring(retValue.length-1, retValue.length);
   while (ch == " ") { // Check for spaces at the end of the string
      retValue = retValue.substring(0, retValue.length-1);
      ch = retValue.substring(retValue.length-1, retValue.length);
   }
   return retValue; // Return the trimmed string back to the user
}