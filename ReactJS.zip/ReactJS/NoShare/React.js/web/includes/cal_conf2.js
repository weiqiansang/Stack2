
//Define calendar(s): addCalendar ("Unique Calendar Name", "Window title", "Form element's name", Form name")
addCalendar("Calendar1", "Select Date", "updFromDate", "frmAdHocSelCond");
addCalendar("Calendar2", "Select Date", "updToDate", "frmAdHocSelCond");
addCalendar("Calendar3", "Select Date", "subFromDate", "frmAdHocSelCond");
addCalendar("Calendar4", "Select Date", "subToDate", "frmAdHocSelCond");
addCalendar("Calendar5", "Select Date", "effectiveDate", "frmNewVarReq");
addCalendar("Calendar6", "Select Date", "expiryDate", "frmNewVarReq");
addCalendar("Calendar7", "Select Date", "CATDate", "frmNewVarReq");
addCalendar("Calendar8", "Select Date", "lenderDate", "frmNewVarReq");
addCalendar("Calendar9", "Select Date", "assignedDate", "frmNewVarReq");
addCalendar("Calendar10", "Select Date", "fromDateStr", "frmTrackerLog");
addCalendar("Calendar11", "Select Date", "toDateStr", "frmTrackerLog");
addCalendar("Calendar12", "Select Date", "fromDateStr", "frmCVTrackRpt");
addCalendar("Calendar13", "Select Date", "toDateStr", "frmCVTrackRpt");
addCalendar("Calendar14", "Select Date", "statChangedDateFrom", "frmDtlVarRpt");
addCalendar("Calendar15", "Select Date", "statChangedDateTo", "frmDtlVarRpt");
addCalendar("Calendar16", "Select Date", "hoaTurnOverDate", "pewForm");
addCalendar("Calendar17", "Select Date", "closingDate", "frmSLW");
addCalendar("Calendar18", "Select Date", "subDateFrom", "slwSummForm");
addCalendar("Calendar19", "Select Date", "subDateTo", "slwSummForm");
addCalendar("Calendar20", "Select Date", "statChangedDateFrom", "slwSummForm");
addCalendar("Calendar21", "Select Date", "statChangedDateTo", "slwSummForm");
addCalendar("Calendar22", "Select Date", "subDateFrom", "pewSummForm");
addCalendar("Calendar23", "Select Date", "subDateTo", "pewSummForm");
addCalendar("Calendar24", "Select Date", "statChangedDateFrom", "pewSummForm");
addCalendar("Calendar25", "Select Date", "statChangedDateTo", "pewSummForm");
addCalendar("Calendar26", "Select Date", "statChangedDateFrom", "feeReportForm");
addCalendar("Calendar27", "Select Date", "statChangedDateTo", "feeReportForm");
addCalendar("Calendar28", "Select Date", "agrmtDate", "frmNewCustAgrmt");


// default settings for English
// Uncomment desired lines and modify its values
// setFont("verdana", 9);
 setWidth(90, 1, 15, 1);
 setColor("lightsteelblue", "lightsteelblue", "#ffffff", "#ffffff", "steelblue", "lightsteelblue", "steelblue");
// setFontColor("#333333", "#333333", "#333333", "#ffffff", "#333333");
setFormat("mm/dd/yyyy");
// setSize(200, 200, -200, 16);

// setWeekDay(0);
// setMonthNames("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
// setDayNames("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Saturday");
// setLinkNames("[Close]", "[Clear]");
