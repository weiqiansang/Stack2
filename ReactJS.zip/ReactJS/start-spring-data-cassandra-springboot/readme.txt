
https://grokonez.com/spring-framework/spring-boot/start-spring-data-cassandra-springboot

Lib:
a) org.springframework.data package
https://jar-download.com/download-handling.php


Location:

stb:
libraryDependencies += "org.springframework.data" % "spring-data-cassandra" % "2.0.4.RELEASE" //Thanks for using https://jar-download.com 

Maven
<dependency>
	<groupId>org.springframework.data</groupId>
	<artifactId>spring-data-cassandra</artifactId>
	<version>2.0.4.RELEASE</version>
</dependency>

